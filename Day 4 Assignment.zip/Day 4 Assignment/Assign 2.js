//Button 1 to change color of div

function changeColor()
{
    document.querySelector(".mydiv").style.backgroundColor="lightblue";
}

//Button 2 to change size of div

function changeSize()
{
    document.querySelector(".mydiv").style.width="600px";
    document.querySelector(".mydiv").style.height="600px";
    document.querySelector(".image").style.width="300px";
    document.querySelector(".image").style.height="300px";
    document.querySelector(".image").style.marginTop="150px";
    document.querySelector(".image").style.marginLeft="150px";
}

//Button 3 to add a image in div

function addImg()
{
    document.querySelector(".image").setAttribute("src","pexels-photo-4737522.jpeg")
}

//Button 4 to remove a image from div

function removeImg()
{
    document.querySelector(".image").setAttribute("src","None")
}
